import { Component, OnInit } from '@angular/core';
import { Post } from 'src/app/interface/post';
import { PostService } from 'src/app/service/posts.service';
//import { recupera, aggiorna } from 'src/app/service/posts.service';

@Component({
  selector: 'app-post-attivi',
  templateUrl: './post-attivi.component.html',
  styleUrls: ['./post-attivi.component.scss']
})
export class PostAttiviComponent implements OnInit {

  posts!: Post[];
  //i!:number

  constructor(private postSrv: PostService) { }

  async ngOnInit(){
    const posts = await this.postSrv.getPosts();
    this.posts = posts;
  }

  disattiva(id: number, i:number){
    this.postSrv.updatePost({active: false}, id);
    this.posts.splice(i,1);
  }

}
