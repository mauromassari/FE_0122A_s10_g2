import { Component, Input, OnInit } from '@angular/core';
import { Post } from 'src/app/interface/post';
import { PostService } from 'src/app/service/posts.service';

import { ActivatedRoute } from '@angular/router'; // <---------

@Component({
  selector: 'app-post-details',
  templateUrl: './post-details.component.html',
  styleUrls: ['./post-details.component.scss']
})
export class PostDetailsComponent implements OnInit {

  //@Input() post!: Post;

  posts!: Post[];

  href!: any; // <--------- url post selezionato
  idPost!: number // <--------- id post selezionato e parsato
  postSelezionato!: any; // <--------- post selezionato

  constructor(private postSrv: PostService,
    private router: ActivatedRoute ) {} // <---------

  async ngOnInit(){
    const posts = await this.postSrv.getPosts();
    this.posts = posts;

    this.href = this.router.url;
    this.idPost = JSON.parse(this.href._value[1]);

    this.postSelezionato = this.postSrv.getPost(this.idPost)

    console.log(this.postSrv.getPost(this.idPost));


  }

}
