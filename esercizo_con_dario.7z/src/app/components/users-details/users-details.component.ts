import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/interface/user';
import { UsersService } from 'src/app/service/users.service';

import { ActivatedRoute } from '@angular/router'; // <---------
import { Router } from '@angular/router'; // <---------





@Component({
  selector: 'app-users-details',
  templateUrl: './users-details.component.html',
  styleUrls: ['./users-details.component.scss']
})
export class UsersDetailsComponent implements OnInit {

  user: User | undefined

  //urlUser!:string;

  //idUser!: number // <--------- id url selezionato e parsato


  //users!: User[];
  //href!: any; // <--------- url user selezionato
  //userSelezionato!: any; // <--------- post selezionato

  constructor(private usersSrv: UsersService, private router: ActivatedRoute) { }

  ngOnInit(): void {

    this.router.params.subscribe(params =>{
      const id = +params['id'];
      this.user = this.usersSrv.getUser(id)
    })

    //console.log(this.urlUser);
    //console.log( window.location.href);

    //const users = this.usersSrv.getUsers();
    //this.users = users;
    //var preHref = this.router.url;

    //this.idUser = JSON.parse(this.href._value[1]);

    //this.userSelezionato = this.usersSrv.getUser(this.idUser)

    //this.user = this.userSelezionato

    //console.log(preHref);

  }





}
