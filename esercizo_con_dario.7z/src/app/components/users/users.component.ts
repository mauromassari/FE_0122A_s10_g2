import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/interface/user';
import { UsersService } from 'src/app/service/users.service';
import { RouterModule } from '@angular/router';
import { Router } from '@angular/router'; // <---------

@Component({
    selector: 'app-users',
    templateUrl: './users.component.html',
    styleUrls: ['./users.component.scss'],
})
export class UsersComponent implements OnInit {
    users!: User[];

    constructor(private usersSrv: UsersService, private router: Router) {}

    ngOnInit(): void {
      this.users = this.usersSrv.getUsers();


    }
}
