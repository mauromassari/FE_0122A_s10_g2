import { Injectable } from '@angular/core';
import { Post } from "../interface/post";

@Injectable ({
  providedIn: 'root',
})

export class PostService{

  posts: Post[] = [
    {
      id: 1,
      body: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent in mattis odio, a egestas est. Ut porta metus ut augue luctus, ac efficitur sapien scelerisque. Donec aliquet, mauris sit amet sagittis vestibulum, ipsum dui dictum tellus, ac bibendum quam libero sed arcu. Ut dictum ipsum lacus, in posuere ante pretium et. Integer non nunc congue, faucibus diam nec, gravida felis. Donec bibendum malesuada commodo. Curabitur vitae tristique erat. Nulla sed lectus consectetur, fringilla dui sit amet, iaculis metus. Mauris placerat libero nec orci dictum varius sit amet at tortor. Suspendisse sed turpis a eros varius ultrices ac quis risus. Vestibulum consectetur ullamcorper ligula, eu posuere arcu tincidunt id. Vestibulum ut laoreet risus. Sed vel faucibus libero, non dignissim ex.',
      title: 'Lorem ipsum dolor sit amet',
      active: true,
      type: 'notizie',
      author: "Giulio"
    },

    {
      id: 2,
      body: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent in mattis odio, a egestas est. Ut porta metus ut augue luctus, ac efficitur sapien scelerisque. Donec aliquet, mauris sit amet sagittis vestibulum, ipsum dui dictum tellus, ac bibendum quam libero sed arcu. Ut dictum ipsum lacus, in posuere ante pretium et. Integer non nunc congue, faucibus diam nec, gravida felis. Donec bibendum malesuada commodo. Curabitur vitae tristique erat. Nulla sed lectus consectetur, fringilla dui sit amet, iaculis metus. Mauris placerat libero nec orci dictum varius sit amet at tortor. Suspendisse sed turpis a eros varius ultrices ac quis risus. Vestibulum consectetur ullamcorper ligula, eu posuere arcu tincidunt id. Vestibulum ut laoreet risus. Sed vel faucibus libero, non dignissim ex.',
      title: 'Lorem ipsum dolor sit amet',
      active: true,
      type: 'politica',
      author: "Luca"
    },

    {
      id: 3,
      body: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent in mattis odio, a egestas est. Ut porta metus ut augue luctus, ac efficitur sapien scelerisque. Donec aliquet, mauris sit amet sagittis vestibulum, ipsum dui dictum tellus, ac bibendum quam libero sed arcu. Ut dictum ipsum lacus, in posuere ante pretium et. Integer non nunc congue, faucibus diam nec, gravida felis. Donec bibendum malesuada commodo. Curabitur vitae tristique erat. Nulla sed lectus consectetur, fringilla dui sit amet, iaculis metus. Mauris placerat libero nec orci dictum varius sit amet at tortor. Suspendisse sed turpis a eros varius ultrices ac quis risus. Vestibulum consectetur ullamcorper ligula, eu posuere arcu tincidunt id. Vestibulum ut laoreet risus. Sed vel faucibus libero, non dignissim ex.',
      title: 'Lorem ipsum dolor sit amet',
      active: false,
      type: 'formazione',
      author: "Maria"
    },

    {
      id: 4,
      body: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent in mattis odio, a egestas est. Ut porta metus ut augue luctus, ac efficitur sapien scelerisque. Donec aliquet, mauris sit amet sagittis vestibulum, ipsum dui dictum tellus, ac bibendum quam libero sed arcu. Ut dictum ipsum lacus, in posuere ante pretium et. Integer non nunc congue, faucibus diam nec, gravida felis. Donec bibendum malesuada commodo. Curabitur vitae tristique erat. Nulla sed lectus consectetur, fringilla dui sit amet, iaculis metus. Mauris placerat libero nec orci dictum varius sit amet at tortor. Suspendisse sed turpis a eros varius ultrices ac quis risus. Vestibulum consectetur ullamcorper ligula, eu posuere arcu tincidunt id. Vestibulum ut laoreet risus. Sed vel faucibus libero, non dignissim ex.',
      title: 'Lorem ipsum dolor sit amet',
      active: true,
      type: 'notizie',
      author: "Giulio"
    },

    {
      id: 5,
      body: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent in mattis odio, a egestas est. Ut porta metus ut augue luctus, ac efficitur sapien scelerisque. Donec aliquet, mauris sit amet sagittis vestibulum, ipsum dui dictum tellus, ac bibendum quam libero sed arcu. Ut dictum ipsum lacus, in posuere ante pretium et. Integer non nunc congue, faucibus diam nec, gravida felis. Donec bibendum malesuada commodo. Curabitur vitae tristique erat. Nulla sed lectus consectetur, fringilla dui sit amet, iaculis metus. Mauris placerat libero nec orci dictum varius sit amet at tortor. Suspendisse sed turpis a eros varius ultrices ac quis risus. Vestibulum consectetur ullamcorper ligula, eu posuere arcu tincidunt id. Vestibulum ut laoreet risus. Sed vel faucibus libero, non dignissim ex.',
      title: 'Lorem ipsum dolor sit amet',
      active: false,
      type: 'politica',
      author: "Giorgia"
    }
  ]

  getPosts(){
    return this.posts;
  }

  getPost(id:number){
    return this.posts.find((post) => post.id == id)
  }

  updatePost(data: Partial<Post>, id:number){
    this.posts = this.posts.map(post =>
      post.id == id ? {...post, ...data} : post);

    return this.posts.find(post => post.id == id) as Post;
  }

}
